﻿using address.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Reflection;

namespace address.Controllers
{
    public class cityController : Controller
    {
        private readonly IConfiguration _configuration;

        public cityController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        private List<SelectListItem> GetStatesSelectList()
        {
            var states = new List<SelectListItem>();
            states.Add(new SelectListItem { Value = "", Text = "Select a State" });

            string connectionString = _configuration.GetConnectionString("ConnectionString");
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand("SELECT StateID, StateName FROM State ORDER BY StateName", connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                states.Add(new SelectListItem
                                {
                                    Value = reader["StateID"].ToString(),
                                    Text = reader["StateName"].ToString()
                                });
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error fetching states: {ex.Message}");
                }
            }
            return states;
        }

        public IActionResult getallCity()
        {
            string connectionString = this._configuration.GetConnectionString("ConnectionString");
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlCommand command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "[dbo].[sp_getall_city]";
            SqlDataReader reader = command.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            return View(table);
        }

        public IActionResult Create()
        {
            ViewBag.States = GetStatesSelectList();
            return View("CityForm", new cityModel());
        }

        public IActionResult Edit(int id)
        {
            cityModel model = GetCityByID(id);
            if (model == null)
            {
                TempData["ErrorMessage"] = "City not found.";
                return RedirectToAction("getallCity");
            }
            ViewBag.States = GetStatesSelectList();
            return View("CityForm", model);
        }

        private cityModel GetCityByID(int cityID)
        {
            cityModel model = null;
            string connectionString = _configuration.GetConnectionString("ConnectionString");
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("[dbo].[sp_get_city_byPK]", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@cityID", cityID);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            model = new cityModel
                            {
                                cityID = Convert.ToInt32(reader["cityID"]),
                                cityName = reader["cityName"].ToString(),
                                pinCode = reader["pinCode"].ToString(),
                                stateID = Convert.ToInt32(reader["stateID"])
                            };
                        }
                    }
                }
            }
            return model;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Save(cityModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    string connectionString = this._configuration.GetConnectionString("ConnectionString");
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        using (SqlCommand command = connection.CreateCommand())
                        {
                            command.CommandType = CommandType.StoredProcedure;

                            if (model.cityID == null || model.cityID == 0)
                            {
                                command.CommandText = "[dbo].[sp_insert_city]";
                                TempData["SuccessMessage"] = "City added successfully.";
                            }
                            else
                            {
                                command.CommandText = "[dbo].[sp_update_city_byPK]";
                                command.Parameters.Add("@cityID", SqlDbType.Int).Value = model.cityID;
                                TempData["SuccessMessage"] = "City updated successfully.";
                            }
                            command.Parameters.Add("@cityName", SqlDbType.VarChar).Value = model.cityName;
                            command.Parameters.Add("@pinCode", SqlDbType.VarChar).Value = model.pinCode;
                            command.Parameters.Add("@stateID", SqlDbType.Int).Value = model.stateID;
                            command.ExecuteNonQuery();
                        }
                    }
                    return RedirectToAction("getallCity");
                }
                catch (SqlException ex)
                {
                    TempData["ErrorMessage"] = "A database error occurred: " + ex.Message;
                }
                catch (Exception ex)
                {
                    TempData["ErrorMessage"] = "An unexpected error occurred: " + ex.Message;
                }
            }

            ViewBag.States = GetStatesSelectList();
            return View("CityForm", model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult deleteCity(int cityID)
        {
            try
            {
                string connectionString = _configuration.GetConnectionString("ConnectionString");
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandText = "[dbo].[sp_delete_city_byPK]";
                        command.Parameters.Add("@cityID", SqlDbType.Int).Value = cityID;
                        command.ExecuteNonQuery();
                    }
                }
                TempData["SuccessMessage"] = "City deleted successfully.";
            }
            catch (SqlException ex)
            {
                TempData["ErrorMessage"] = "A database error occurred while deleting the city: " + ex.Message;
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "An unexpected error occurred while deleting the city: " + ex.Message;
            }
            return RedirectToAction("getallCity");
        }
    }
}