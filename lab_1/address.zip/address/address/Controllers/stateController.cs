﻿using address.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering; 
using Microsoft.Data.SqlClient;
using System.Data;

namespace address.Controllers
{
    public class StateController : Controller 
    {
        private readonly IConfiguration _configuration;

        public StateController(IConfiguration configuration) 
        {
            _configuration = configuration;
        }

        private List<SelectListItem> GetCountriesSelectList()
        {
            var countries = new List<SelectListItem>();
            string connectionString = _configuration.GetConnectionString("ConnectionString");
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand("SELECT CountryID, CountryName FROM Country ORDER BY CountryName", connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                countries.Add(new SelectListItem
                                {
                                    Value = reader["CountryID"].ToString(),
                                    Text = reader["CountryName"].ToString()
                                });
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error fetching countries: {ex.Message}");
                }
            }
            return countries;
        }

        public IActionResult getallState()
        {
            string connectionString = this._configuration.GetConnectionString("ConnectionString");
            DataTable table = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = connection.CreateCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "[dbo].[sp_getall_state]";
                    SqlDataReader reader = command.ExecuteReader();
                    table.Load(reader);
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Could not load states: " + ex.Message;
            }
            return View(table);
        }

        public IActionResult insertState()
        {
            ViewBag.Countries = GetCountriesSelectList();
            return View("StateForm", new stateModel());
        }

        public IActionResult Edit(int id)
        {
            stateModel model = GetStateByID(id);
            if (model == null)
            {
                TempData["ErrorMessage"] = "State not found.";
                return RedirectToAction("getallState");
            }
            ViewBag.Countries = GetCountriesSelectList();
            return View("StateForm", model);
        }

        private stateModel GetStateByID(int stateID)
        {
            stateModel model = null;
            string connectionString = _configuration.GetConnectionString("ConnectionString");
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("[dbo].[sp_get_state_byPK]", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@stateID", stateID);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            model = new stateModel
                            {
                                stateID = Convert.ToInt32(reader["stateID"]),
                                stateName = reader["stateName"].ToString(),
                                stateCode = reader["stateCode"].ToString(),
                                countryID = Convert.ToInt32(reader["countryID"])
                            };
                        }
                    }
                }
            }
            return model;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult SaveState(stateModel model) 
        {
            if (ModelState.IsValid)
            {
                try
                {
                    string connectionString = this._configuration.GetConnectionString("ConnectionString");
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        using (SqlCommand command = connection.CreateCommand())
                        {
                            command.CommandType = CommandType.StoredProcedure;

                            if (model.stateID == null || model.stateID == 0)
                            {
                                command.CommandText = "[dbo].[sp_insert_state]";
                                TempData["SuccessMessage"] = "State added successfully.";
                            }
                            else
                            {
                                command.CommandText = "[dbo].[sp_update_state_byPK]";
                                command.Parameters.Add("@stateID", SqlDbType.Int).Value = model.stateID;
                                TempData["SuccessMessage"] = "State updated successfully.";
                            }
                            command.Parameters.Add("@stateName", SqlDbType.VarChar).Value = model.stateName;
                            command.Parameters.Add("@stateCode", SqlDbType.VarChar).Value = model.stateCode;
                            command.Parameters.Add("@countryID", SqlDbType.Int).Value = model.countryID;
                            command.ExecuteNonQuery();
                        }
                    }
                    return RedirectToAction("getallState");
                }
                catch (SqlException ex)
                {
                    TempData["ErrorMessage"] = "A database error occurred: " + ex.Message;
                }
                catch (Exception ex)
                {
                    TempData["ErrorMessage"] = "An unexpected error occurred: " + ex.Message;
                }
            }
            ViewBag.Countries = GetCountriesSelectList();
            return View("StateForm", model);
        }

        public IActionResult deleteState(int stateID)
        {
            try
            {
                string connectionString = _configuration.GetConnectionString("ConnectionString");
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandText = "[dbo].[sp_delete_state_byPK]";
                        command.Parameters.Add("@stateID", SqlDbType.Int).Value = stateID;
                        command.ExecuteNonQuery();
                    }
                }
                TempData["SuccessMessage"] = "State deleted successfully.";
            }
            catch (SqlException ex) when (ex.Number == 547) // Foreign key violation
            {
                TempData["ErrorMessage"] = "Cannot delete state. It is referenced by one or more cities.";
            }
            catch (SqlException ex)
            {
                TempData["ErrorMessage"] = "A database error occurred while deleting the state: " + ex.Message;
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "An unexpected error occurred while deleting the state: " + ex.Message;
            }
            return RedirectToAction("getallState");
        }
    }
}