﻿using address.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Data;

namespace address.Controllers
{
    public class countryController : Controller
    {
        private readonly IConfiguration _configuration;

        public countryController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public IActionResult getallCountry()
        {
            string connectionString = this._configuration.GetConnectionString("ConnectionString");
            DataTable table = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "[dbo].[sp_getall_country]";
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        table.Load(reader);
                    }
                }
            }
            return View(table);
        }

        public IActionResult CreateCountry()
        {
            return View("CountryForm", new countryModel());
        }

        public IActionResult Edit(int id) 
        {
            countryModel model = GetCountryById(id);
            if (model == null)
            {
                TempData["ErrorMessage"] = "Country not found.";
                return RedirectToAction("getallCountry");
            }
            return View("CountryForm", model);
        }

        private countryModel GetCountryById(int countryID)
        {
            countryModel model = null;
            string connectionString = _configuration.GetConnectionString("ConnectionString");
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("[dbo].[sp_get_country_byPK]", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@countryID", countryID);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            model = new countryModel
                            {
                                countryID = Convert.ToInt32(reader["countryID"]),
                                countryName = reader["countryName"].ToString()
                            };
                        }
                    }
                }
            }
            return model;
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult SaveCountry(countryModel model) 
        {
            if (ModelState.IsValid)
            {
                try
                {
                    string connectionString = this._configuration.GetConnectionString("ConnectionString");
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        using (SqlCommand command = connection.CreateCommand())
                        {
                            command.CommandType = CommandType.StoredProcedure;

                            if (model.countryID == null || model.countryID == 0)
                            {
                                command.CommandText = "[dbo].[sp_insert_country]";
                                TempData["SuccessMessage"] = "Country added successfully.";
                            }
                            else 
                            {
                                command.CommandText = "[dbo].[sp_update_country_byPK]";
                                command.Parameters.Add("@countryID", SqlDbType.Int).Value = model.countryID;
                                TempData["SuccessMessage"] = "Country updated successfully.";
                            }
                            command.Parameters.Add("@countryName", SqlDbType.VarChar).Value = model.countryName; 
                            command.ExecuteNonQuery();
                        }
                    }
                    return RedirectToAction("getallCountry");
                }
                catch (SqlException ex)
                {
                    TempData["ErrorMessage"] = "A database error occurred: " + ex.Message;
                }
                catch (Exception ex)
                {
                    TempData["ErrorMessage"] = "An unexpected error occurred: " + ex.Message;
                }
            }
            return View("CountryForm", model);
        }

        public IActionResult deleteCountry(int countryID)
        {
            try
            {
                string connectionString = _configuration.GetConnectionString("ConnectionString");
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandText = "[dbo].[sp_delete_country_byPK]";
                        command.Parameters.Add("@countryID", SqlDbType.Int).Value = countryID;
                        command.ExecuteNonQuery();
                    }
                }
                TempData["SuccessMessage"] = "Country deleted successfully.";
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                TempData["ErrorMessage"] = "Cannot delete country. It is referenced by existing states.";
            }
            catch (SqlException ex)
            {
                TempData["ErrorMessage"] = "A database error occurred while deleting the country: " + ex.Message;
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "An unexpected error occurred while deleting the country: " + ex.Message;
            }
            return RedirectToAction("getallCountry");
        }
    }
}