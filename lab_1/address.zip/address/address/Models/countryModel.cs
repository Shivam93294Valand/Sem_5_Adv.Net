﻿using System.ComponentModel.DataAnnotations;

namespace address.Models
{
    public class countryModel
    {
        public int? countryID { get; set; }

        [Required(ErrorMessage = "Please enter a country name")]
        public string countryName { get; set; }
    }
}