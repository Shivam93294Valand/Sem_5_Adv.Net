﻿using System.ComponentModel.DataAnnotations;

namespace address.Models
{
    public class stateModel
    {
        public int? stateID { get; set; } 

        [Required(ErrorMessage = "State Name is required.")]
        [Display(Name = "State Name")]
        [StringLength(100, ErrorMessage = "State Name cannot be longer than 100 characters.")]
        public string stateName { get; set; }

        [Required(ErrorMessage = "State Code is required.")]
        [Display(Name = "State Code")]
        [StringLength(10, ErrorMessage = "State Code cannot be longer than 10 characters.")] // Adjusted max length
        public string stateCode { get; set; }

        [Required(ErrorMessage = "Please select a country.")]
        [Range(1, int.MaxValue, ErrorMessage = "Please select a valid country.")] // Assumes CountryID starts from 1
        [Display(Name = "Country")]
        public int countryID { get; set; }

        // Optional: If you want to display CountryName in some contexts with the model
        // public string CountryName { get; set; }

        // Optional: If you want to pass the list of countries through the model instead of ViewBag
        // public List<Microsoft.AspNetCore.Mvc.Rendering.SelectListItem> Countries { get; set; }
    }
}