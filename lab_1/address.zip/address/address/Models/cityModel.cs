﻿using System.ComponentModel.DataAnnotations;

namespace address.Models
{
    public class cityModel
    {
        public int? cityID { get; set; }

        [Required]
        [Display(Name = "CityName")]
        public string cityName { get; set; }

        [Required]
        [Display(Name = "pincode")]
        public string pinCode { get; set; }

        [Required]
        [Display(Name = "StateID")]
        public int stateID { get; set; }
    }
}